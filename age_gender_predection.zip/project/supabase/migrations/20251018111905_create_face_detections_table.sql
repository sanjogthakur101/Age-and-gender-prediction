/*
  # Create Face Detections Table

  1. New Tables
    - `face_detections`
      - `id` (uuid, primary key) - Unique identifier for each detection
      - `gender` (text) - Detected gender (Male/Female)
      - `gender_confidence` (numeric) - Confidence score for gender prediction (0-1)
      - `age` (integer) - Predicted age
      - `age_range` (text) - Age range category (e.g., "25-34")
      - `detected_at` (timestamptz) - Timestamp when detection occurred
      - `session_id` (uuid) - Groups multiple detections from same session
      - `created_at` (timestamptz) - Record creation timestamp

  2. Security
    - Enable RLS on `face_detections` table
    - Add policy for public insert (anonymous users can save detections)
    - Add policy for public read (anyone can view detection statistics)

  3. Indexes
    - Index on `session_id` for efficient session queries
    - Index on `detected_at` for time-based queries
*/

CREATE TABLE IF NOT EXISTS face_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gender text NOT NULL,
  gender_confidence numeric NOT NULL CHECK (gender_confidence >= 0 AND gender_confidence <= 1),
  age integer NOT NULL CHECK (age >= 0 AND age <= 120),
  age_range text NOT NULL,
  detected_at timestamptz NOT NULL DEFAULT now(),
  session_id uuid NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE face_detections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert face detections"
  ON face_detections
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view face detections"
  ON face_detections
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_face_detections_session_id ON face_detections(session_id);
CREATE INDEX IF NOT EXISTS idx_face_detections_detected_at ON face_detections(detected_at DESC);
