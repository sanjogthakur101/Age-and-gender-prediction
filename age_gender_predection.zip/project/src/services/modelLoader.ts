import * as faceapi from 'face-api.js';

export class ModelLoader {
  private static isLoaded = false;

  static async loadModels(): Promise<void> {
    if (this.isLoaded) return;

    const MODEL_URL = 'https://cdn.jsdelivr.net/gh/cgarciagl/face-api.js/weights';

    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.ageGenderNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
    ]);

    this.isLoaded = true;
  }

  static isModelsLoaded(): boolean {
    return this.isLoaded;
  }
}
