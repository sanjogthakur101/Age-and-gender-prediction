import * as faceapi from 'face-api.js';
import { ModelLoader } from './modelLoader';

export interface FaceDetection {
  box: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  gender: string;
  genderConfidence: number;
  age: number;
  ageRange: string;
}

class FaceDetectionService {
  private isInitialized = false;

  async initialize() {
    if (this.isInitialized) return;
    await ModelLoader.loadModels();
    this.isInitialized = true;
  }

  async detectFaces(videoElement: HTMLVideoElement): Promise<FaceDetection[]> {
    if (!this.isInitialized) {
      throw new Error('Model not initialized');
    }

    const detections = await faceapi
      .detectAllFaces(videoElement, new faceapi.TinyFaceDetectorOptions())
      .withAgeAndGender();

    return detections.map(detection => {
      const box = detection.detection.box;

      let ageRange: string;
      const age = Math.round(detection.age);
      if (age < 18) ageRange = '0-17';
      else if (age < 25) ageRange = '18-24';
      else if (age < 35) ageRange = '25-34';
      else if (age < 45) ageRange = '35-44';
      else if (age < 60) ageRange = '45-59';
      else ageRange = '60+';

      return {
        box: {
          x: box.x,
          y: box.y,
          width: box.width,
          height: box.height,
        },
        gender: detection.gender,
        genderConfidence: detection.genderProbability,
        age: age,
        ageRange: ageRange,
      };
    });
  }

  isReady(): boolean {
    return this.isInitialized;
  }
}

export const faceDetectionService = new FaceDetectionService();
