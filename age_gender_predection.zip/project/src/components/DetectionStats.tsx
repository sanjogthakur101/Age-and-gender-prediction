import { Users, TrendingUp, Clock, Activity } from 'lucide-react';
import { FaceDetection } from '../services/faceDetection';

interface DetectionStatsProps {
  currentDetections: FaceDetection[];
  totalDetections: number;
  sessionStart: Date;
}

export function DetectionStats({ currentDetections, totalDetections, sessionStart }: DetectionStatsProps) {
  const duration = Math.floor((Date.now() - sessionStart.getTime()) / 1000);
  const minutes = Math.floor(duration / 60);
  const seconds = duration % 60;

  const maleCount = currentDetections.filter(d => d.gender === 'Male').length;
  const femaleCount = currentDetections.filter(d => d.gender === 'Female').length;
  const avgAge = currentDetections.length > 0
    ? Math.round(currentDetections.reduce((sum, d) => sum + d.age, 0) / currentDetections.length)
    : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl mx-auto">
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-emerald-100 p-2 rounded-lg">
            <Users className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{currentDetections.length}</div>
        </div>
        <div className="text-sm text-gray-600">Faces Detected</div>
        {currentDetections.length > 0 && (
          <div className="mt-2 text-xs text-gray-500">
            {maleCount}M / {femaleCount}F
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-blue-100 p-2 rounded-lg">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{totalDetections}</div>
        </div>
        <div className="text-sm text-gray-600">Total Analyzed</div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-purple-100 p-2 rounded-lg">
            <Activity className="w-5 h-5 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">
            {avgAge > 0 ? `${avgAge}y` : '-'}
          </div>
        </div>
        <div className="text-sm text-gray-600">Average Age</div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-orange-100 p-2 rounded-lg">
            <Clock className="w-5 h-5 text-orange-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">
            {minutes}:{seconds.toString().padStart(2, '0')}
          </div>
        </div>
        <div className="text-sm text-gray-600">Session Time</div>
      </div>
    </div>
  );
}
