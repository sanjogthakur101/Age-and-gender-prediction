import { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, Loader2 } from 'lucide-react';
import { faceDetectionService, FaceDetection } from '../services/faceDetection';

interface CameraViewProps {
  onDetection: (detections: FaceDetection[]) => void;
  isActive: boolean;
}

export function CameraView({ onDetection, isActive }: CameraViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const detectionIntervalRef = useRef<number>();

  useEffect(() => {
    let mounted = true;

    async function initializeCamera() {
      try {
        setIsLoading(true);
        setError('');

        await faceDetectionService.initialize();

        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: 640, height: 480 }
        });

        if (!mounted) {
          mediaStream.getTracks().forEach(track => track.stop());
          return;
        }

        setStream(mediaStream);

        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          await videoRef.current.play();
        }

        setIsLoading(false);
      } catch (err) {
        if (mounted) {
          setError('Failed to access camera. Please grant camera permissions.');
          setIsLoading(false);
        }
      }
    }

    if (isActive) {
      initializeCamera();
    }

    return () => {
      mounted = false;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, [isActive]);

  useEffect(() => {
    if (!isActive || isLoading || !videoRef.current || !canvasRef.current) {
      return;
    }

    const detectFaces = async () => {
      if (!videoRef.current || !canvasRef.current) return;

      try {
        const detections = await faceDetectionService.detectFaces(videoRef.current);

        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        detections.forEach(detection => {
          const { box, gender, age, genderConfidence } = detection;

          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 3;
          ctx.strokeRect(box.x, box.y, box.width, box.height);

          ctx.fillStyle = '#10b981';
          ctx.font = 'bold 16px sans-serif';

          const text = `${gender}, ${age}y (${Math.round(genderConfidence * 100)}%)`;
          const textWidth = ctx.measureText(text).width;

          ctx.fillRect(box.x, box.y - 30, textWidth + 16, 28);

          ctx.fillStyle = '#ffffff';
          ctx.fillText(text, box.x + 8, box.y - 10);
        });

        if (detections.length > 0) {
          onDetection(detections);
        }
      } catch (err) {
        console.error('Detection error:', err);
      }
    };

    detectionIntervalRef.current = window.setInterval(detectFaces, 500);

    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, [isActive, isLoading, onDetection]);

  if (error) {
    return (
      <div className="relative w-full max-w-2xl mx-auto bg-gray-900 rounded-2xl overflow-hidden aspect-video flex items-center justify-center">
        <div className="text-center p-8">
          <CameraOff className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <p className="text-white text-lg">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      {isLoading && (
        <div className="absolute inset-0 bg-gray-900 rounded-2xl flex items-center justify-center z-10">
          <div className="text-center">
            <Loader2 className="w-12 h-12 text-emerald-400 animate-spin mx-auto mb-4" />
            <p className="text-white">Initializing camera and AI models...</p>
          </div>
        </div>
      )}

      <div className="relative bg-gray-900 rounded-2xl overflow-hidden shadow-2xl">
        <video
          ref={videoRef}
          className="w-full h-auto"
          playsInline
          muted
        />
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 w-full h-full"
        />

        <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full flex items-center gap-2 text-sm font-semibold">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          LIVE
        </div>
      </div>
    </div>
  );
}
