import { useEffect, useState } from 'react';
import { BarChart3, User, Calendar } from 'lucide-react';
import { supabase, FaceDetectionRecord } from '../lib/supabase';

interface AgeDistribution {
  [key: string]: number;
}

interface GenderStats {
  male: number;
  female: number;
}

export function DetectionHistory() {
  const [recentDetections, setRecentDetections] = useState<FaceDetectionRecord[]>([]);
  const [genderStats, setGenderStats] = useState<GenderStats>({ male: 0, female: 0 });
  const [ageDistribution, setAgeDistribution] = useState<AgeDistribution>({});

  useEffect(() => {
    loadHistory();

    const channel = supabase
      .channel('face_detections_changes')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'face_detections' },
        () => {
          loadHistory();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function loadHistory() {
    const { data, error } = await supabase
      .from('face_detections')
      .select('*')
      .order('detected_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Error loading history:', error);
      return;
    }

    if (data) {
      setRecentDetections(data);

      const maleCount = data.filter(d => d.gender === 'Male').length;
      const femaleCount = data.filter(d => d.gender === 'Female').length;
      setGenderStats({ male: maleCount, female: femaleCount });

      const ageGroups: AgeDistribution = {};
      data.forEach(d => {
        ageGroups[d.age_range] = (ageGroups[d.age_range] || 0) + 1;
      });
      setAgeDistribution(ageGroups);
    }
  }

  const total = genderStats.male + genderStats.female;
  const malePercentage = total > 0 ? (genderStats.male / total) * 100 : 0;
  const femalePercentage = total > 0 ? (genderStats.female / total) * 100 : 0;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <BarChart3 className="w-6 h-6 text-emerald-600" />
          <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <User className="w-5 h-5" />
              Gender Distribution
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Male</span>
                  <span className="text-sm font-semibold text-blue-600">
                    {genderStats.male} ({Math.round(malePercentage)}%)
                  </span>
                </div>
                <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 transition-all duration-500"
                    style={{ width: `${malePercentage}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Female</span>
                  <span className="text-sm font-semibold text-pink-600">
                    {genderStats.female} ({Math.round(femalePercentage)}%)
                  </span>
                </div>
                <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-pink-500 transition-all duration-500"
                    style={{ width: `${femalePercentage}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Age Distribution
            </h3>
            <div className="space-y-3">
              {Object.entries(ageDistribution)
                .sort((a, b) => a[0].localeCompare(b[0]))
                .map(([range, count]) => {
                  const percentage = total > 0 ? (count / total) * 100 : 0;
                  return (
                    <div key={range}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700">{range}</span>
                        <span className="text-sm font-semibold text-emerald-600">
                          {count} ({Math.round(percentage)}%)
                        </span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Detections</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Time</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Gender</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Age</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {recentDetections.slice(0, 10).map((detection) => (
                <tr key={detection.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 text-sm text-gray-600">
                    {new Date(detection.detected_at!).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      detection.gender === 'Male'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-pink-100 text-pink-800'
                    }`}>
                      {detection.gender}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-900 font-medium">
                    {detection.age} years
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-600">
                    {Math.round(detection.gender_confidence * 100)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {recentDetections.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No detections yet. Start the camera to begin analyzing!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
