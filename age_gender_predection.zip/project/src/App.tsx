import { useState, useEffect, useCallback } from 'react';
import { Video, VideoOff, Brain } from 'lucide-react';
import { CameraView } from './components/CameraView';
import { DetectionStats } from './components/DetectionStats';
import { DetectionHistory } from './components/DetectionHistory';
import { FaceDetection } from './services/faceDetection';
import { supabase, FaceDetectionRecord } from './lib/supabase';

function App() {
  const [isActive, setIsActive] = useState(false);
  const [currentDetections, setCurrentDetections] = useState<FaceDetection[]>([]);
  const [totalDetections, setTotalDetections] = useState(0);
  const [sessionId] = useState(() => crypto.randomUUID());
  const [sessionStart] = useState(() => new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setSessionStart(new Date(sessionStart));
    }, 1000);

    return () => clearInterval(interval);
  }, [sessionStart]);

  const handleDetection = useCallback(async (detections: FaceDetection[]) => {
    setCurrentDetections(detections);

    for (const detection of detections) {
      const record: FaceDetectionRecord = {
        gender: detection.gender,
        gender_confidence: detection.genderConfidence,
        age: detection.age,
        age_range: detection.ageRange,
        session_id: sessionId,
      };

      const { error } = await supabase
        .from('face_detections')
        .insert([record]);

      if (!error) {
        setTotalDetections(prev => prev + 1);
      }
    }
  }, [sessionId]);

  const toggleCamera = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setCurrentDetections([]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8 space-y-8">
        <header className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="bg-emerald-500 p-3 rounded-2xl shadow-lg">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900">
              AI Face Analytics
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Real-time age and gender recognition using advanced machine learning models
          </p>
        </header>

        <div className="flex justify-center">
          <button
            onClick={toggleCamera}
            className={`flex items-center gap-3 px-8 py-4 rounded-xl font-semibold text-lg transition-all transform hover:scale-105 shadow-lg ${
              isActive
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-emerald-500 hover:bg-emerald-600 text-white'
            }`}
          >
            {isActive ? (
              <>
                <VideoOff className="w-6 h-6" />
                Stop Camera
              </>
            ) : (
              <>
                <Video className="w-6 h-6" />
                Start Camera
              </>
            )}
          </button>
        </div>

        {isActive && (
          <div className="space-y-8 animate-fade-in">
            <CameraView onDetection={handleDetection} isActive={isActive} />

            <DetectionStats
              currentDetections={currentDetections}
              totalDetections={totalDetections}
              sessionStart={sessionStart}
            />
          </div>
        )}

        <DetectionHistory />

        <footer className="text-center text-gray-500 text-sm pt-8 pb-4">
          <p>Powered by TensorFlow.js and BlazeFace</p>
          <p className="mt-1">All processing happens locally in your browser</p>
        </footer>
      </div>
    </div>
  );
}

export default App;
